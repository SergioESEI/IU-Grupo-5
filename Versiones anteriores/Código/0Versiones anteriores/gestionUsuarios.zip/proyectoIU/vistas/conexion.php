<?php
session_start();
$mysqli = new mysqli("localhost","root", "123456789", "proyectoIU");
	if(mysqli_connect_errno()){
	echo "conexion fallida";
	exit();	
	}
?>
