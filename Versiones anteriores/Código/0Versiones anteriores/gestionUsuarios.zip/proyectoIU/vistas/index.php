<?php
    require('conexion.php');
    $tamanoPaginas=4;
    $pagina=1;
      if(isset($_GET["pagina"])){
        if($_GET["pagina"]==1){
          header("location:index.php");
        }else{
          $pagina=$_GET["pagina"];
       }
      }else{
        $pagina=1;
      }
      $empezarDesde =($pagina-1)*$tamanoPaginas;
      $query ="SELECT * from usuarios";
      $resultado= $mysqli->query($query);
      $num_filas= $resultado->num_rows;
      $totalPaginas = ceil($num_filas/$tamanoPaginas);
      $sql_limite ="SELECT * from usuarios LIMIT $empezarDesde, $tamanoPaginas";
      $resultado= $mysqli->query($sql_limite);
?>
<?php include "cabecera.php"; ?>
<h1 class="text-primary text-center">Listado de usuarios</h1>
<div class="col-md-12">
  <hr>
</div>
<div class="container">
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <div class="panel panel-primary panel-table">
        <div class="panel-heading"></div>
        <div class="panel-body">
          <a type="button" href="viewNewUser.php"><button type="button" class="btn btn-success">Nuevo usuario</button></a><br>
          <div class="col-md-12">
            <hr>
          </div>
          <table class="table-hover table table-striped table-bordered table-list">
            <thead>
            <tr>
              <th class="info">
                <em class="fa fa-cog"></em>
              </th>
              <th class="hidden-xs info">nombre</th>
              <th class="info">E-mail</th>
              <th class="info">Telefono</th>
            </tr>
            </thead>
            <tbody>
            <?php while($row=$resultado->fetch_assoc()){?>
              <tr>
                <td align="center" class="active">
                    <form action="../controladores/controladorDeleteUser.php" method="post">
                    <input name="opcion" value="editar" type="submit" class="btn btn-info">
                      <input name="opcion" value="editar" type="submit" class="btn btn-info">
                    <a href="../controladores/controladorDeleteUser.php?opcion=borrar"><button type="button" class="btn btn-danger">Borrar</button></a>
                </td>
                  <?php
                        $_SESSION['dni']=$row['dni'];
                        $_SESSION['apellidos']=$row['apellidos'];
                        $_SESSION['nombre']=$row['nombre'];
                        $_SESSION['password']=$row['password'];
                        $_SESSION['urlFoto']=$row['urlFoto'];
                        $_SESSION['telefono']=$row['telefono'];
                        $_SESSION['direccion']=$row['direccion'];
                        $_SESSION['email']=$row['email'];
                        $_SESSION['fechaNac']=$row['fechaNac'];
                        $_SESSION['observaciones']=$row['observaciones'];
                        $_SESSION['numCuenta']=$row['numCuenta'];
                        $_SESSION['externo']=$row['externo'];
                        $_SESSION['horasExtras']=$row['horasExtras'];
                        $_SESSION['grupo']=$row['grupo'];
                        $_SESSION['profesion']=$row['profesion']; ?>
                        <td><?php echo $row['nombre'];?></td>
                        <td><?php echo $row['direccion'];?></td>
                        <td><?php echo $row['telefono'];?></td>
              </tr>
            <?php }?>
            </tbody>
          </table>
          </form>
          <?php

          /*Paginación*/
          for($i=1; $i<=$totalPaginas; $i++){?>
            <?php	echo "<a href='?pagina=" . $i ."'>" . $i . "</a>   ";?>
          <?php } ?>

        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php include "pie.php"; ?>

