
<?php include "cabecera.php"; ?>
        <div class="section">
          <div class="container">
                <div class="col-md-12">
                    <form action="../controladores/controladorUser.php", method="post" class="form-horizontal" role="form">
                        <div class="form-group">
                                <div class="col-md-12"> <h2 class="text-info ">NUEVO USUARIO</h2></div>
                                <div class="col-md-12"><hr></div>

                                <!-- Campo nombre-->
                                <div class="form-group">
                                    <div class="col-sm-4">
                                      <label for="nombre" class="control-label">Nombre Usuario</label>
                                    </div>
                                    <div class="col-sm-4">
                                      <input type="text" class="form-control" name="nombre" id="nombre" placeholder="Nombre Usuario">
                                    </div>
                                </div>
                                <!-- Campo apellido -->
                                <div class="form-group">
                                      <div class="col-sm-4">
                                          <label for="apellidos" class="control-label">Apellido</label>
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="text" class="form-control" name="apellidos" id="apellidos" placeholder="Apellido del usuario"/>
                                      </div>
                                </div>
                                <!-- Campo DNI -->
                                <div class="form-group">
                                      <div class="col-sm-4">
                                          <label for="dni" class="control-label">DNI:</label>
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="text" class="form-control" name="dni" id="dni" placeholder="DNI del usuario">
                                      </div>
                                  </div>
                                <!-- Campo Password -->
                                <div class="form-group">
                                      <div class="col-sm-4">
                                          <label for="password" class="control-label" required>Contraseña del usuario</label>
                                      </div>
                                      <div class="col-sm-3">
                                          <input type="password" class="form-control" id="password" name="password">
                                      </div>
                                  </div>
                                <!-- Campo URL foto -->
                                <div class="form-group">
                                    <div class="col-sm-4">
                                      <label for="url" class="control-label" required>Foto del usuario</label>
                                    </div>
                                    <div class="col-sm-3">
                                      <input type="file" name="urlFoto" accept="image/*" class="form-control" id="urlFoto">
                                    </div>
                                </div>
                                <!-- Campo Telefono -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="telefono" class="control-label" required>Telefono del usuario</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type="tel"class="form-control" name="telefono" id="telefono">
                                  </div>
                                </div>
                                <!-- Campo email -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="email" class="control-label" required>E-mail del usuario</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type="email"  class="form-control" id="emailuser" name="emailuser">
                                  </div>
                                </div>
                                <!-- Campo Direccion -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="direccion" class="control-label" required>Direccion del usuario</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type="text"  class="form-control" id="direccion" name="direccion">
                                  </div>
                                </div>
                                <!-- Campo Fecha nacimiento -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="fechaNac" class="control-label" required>Fecha nacimiento del usuario</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type="date"  class="form-control" id="fechaNac" name="fechaNac">
                                  </div>
                                </div>
                                <!-- Campo Observaciones -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="observaciones" class="control-label">Observación del usuario</label>
                                  </div>
                                  <div class="col-sm-8" id="observaciones" name="observaciones">
                                    <textarea rows="6" cols="62"name="observaciones" id="observaciones"></textarea>
                                  </div>
                                </div>
                                <!-- Campo Número de cuenta -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="numCuenta" class="control-label" required>Número de cuenta del usuario</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type="text"  class="form-control" id="numCuenta" name="numCuenta">
                                  </div>
                                </div>
                                <!-- Campo Externo -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="externo" class="control-label" required>¿Es externo? /S= si, /N=no</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type="text"  class="form-control" id="externo" name="externo">
                                  </div>
                                </div>
                                <!-- Campo Horas extras -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="horasExtras" class="control-label" required>Horas extras</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type="number"  class="form-control" id="horasExtras" name="horasExtras" placeholder="Ejm: 12, 01, 100">
                                  </div>
                                </div>
                                <!-- Campo Horas extras -->
                                <div class="form-group">
                                  <div class="col-sm-4">
                                    <label for="profesion" class="control-label" required>Profesión</label>
                                  </div>
                                  <div class="col-sm-3">
                                    <input type=""  class="form-control" id="profesion" name="profesion">
                                  </div>
                                </div>
                                <!-- Campo Grupo -->
                                <div class="form-group">
                                            <div class="col-sm-4">
                                                <label for="grupo" class="control-label">Grupo del usuario</label>
                                            </div>
                                            <div class="col-sm-8">
                                                <select class="btn btn-primary" id="grupo" name="grupo" selected="Selecciona el grupo">
                                                    <option value=""></option>
                                                    <option value="Administrador">Administrador</option>
                                                    <option value="Minitor">Monitor</option>
                                                    <option value="Fisio">Fisio</option>
                                                    <option value="Secretari@">Secretario</option>
                                                </select>
                                            </div>
                                </div>

                                  <div class="form-group">
                                      <button class="btn btn-default" name="opcion" value="alta"type="submit">Insertar</button>
                                      <div class="col-sm-2"><input class="btn btn-default" type="reset"></div>
                                  </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include "pie.php"; ?>
