<?php
class usuario
{
  var $dni;
  var $nombre;
  var $apellidos;
  var $password;
  var $urlFoto;
  var $telefono;
  var $direccion;
  var $email;
  var $fechaNac;
  var $observaciones;
  var $numCuenta;
  var $externo;
  var $horasExtras;
  var $grupo;
  var $profesion;
  var $conexion;
  var $existeUsuario;
 function __construct($nombre, $apellidos, $dni, $password, $urlFoto, $telefono, $email, $direccion, $fechaNac, $observaciones, $numCuenta, $externo, $horasExtras, $profesion, $grupo)
  {

    $this->apellidos = $apellidos;
    $this->nombre = $nombre;
    $this->dni = $dni;
    $this->password = $password;
    $this->urlFoto = $urlFoto;
    $this->telefono = $telefono;
    $this->email = $email;
    $this->direccion = $direccion;
    $this->fechaNac = $fechaNac;
    $this->observaciones = $observaciones;
    $this->numCuenta = $numCuenta;
    $this->externo = $externo;
    $this->horasExtras = $horasExtras;
    $this->profesion = $profesion;
    $this->grupo = $grupo;
    $this ->conectarBD();
  }
 function conectarBD()
  {
    $this->conexion = new mysqli("localhost", "root", "123456789", "proyectoIU");
    if ($this->conexion->connect_errno) {
      echo "error";
    } else {
      echo "correcto";
    }
  }

  function insertar(){
    if ($this->dni<>'') {
      $sentenciaSql = "SELECT * from usuarios where dni = '". $this->dni ."'";
      $resul=$this->conexion->query($sentenciaSql);
      if ($resul->num_rows==0){
        $existeUsuario=true;
        $consulta = "INSERT INTO usuarios (dni,apellidos,nombre,password,urlFoto,telefono,direccion,email,fechaNac,observaciones,numCuenta,externo,horasExtras,grupo,profesion)VALUES('".$this->dni."','".$this->apellidos."','".$this->nombre."','".$this->password."','".$this->urlFoto."','".$this->telefono."','".$this->email."','".$this->direccion."','".$this->fechaNac."','".$this->observaciones."','".$this->numCuenta."','".$this->externo."','".$this->horasExtras."','".$this->grupo."','".$this->profesion."')";
	echo $consulta; 
	$this->conexion->query($consulta);	
      } else {
        echo "existe ese usuario" . $this->dni;
        $existeUsuario=false;
      }

    }
}
    function borrarUsuario(){
	$sql = "SELECT * from usuarios where dni='" .$this->dni."'";
	$consulta= $this->conexion->query($sql);
	if($consulta->num_rows==0) echo "ese usuario no existe";
	else{ 
		$consultaBorrar = "DELETE from usuarios where dni= '" .$this->dni."'"; 
		$this->conexion->query($consultaBorrar);
		}		
	}


	function modificarUsuario(){
      $sql="SELECT * from usuarios WHERE dni='" .$this->dni."'";
      $consulta=$this->conexion->query($sql);
        if($consulta->num_rows==0){

        }else{
          $consulta = "UPDATE usuarios SET nombre='$this->nombre'
                                      WHERE dni='$this->dni'";
          $this->conexion->query($consulta);
        }
	}
}
?>;
