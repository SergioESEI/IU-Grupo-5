<?php
session_start();
$opcion = $_REQUEST['opcion'];

if($opcion=="alta") header('location: ../vistas/viewNewUser.php');
if($opcion=="baja") header ('location:../vistas/index.php');
?>;
