<?php

include "../modelos/modeloEjemplo.php";
session_start();
$nombre= $_REQUEST['nombre'];
$apellidos= $_REQUEST['apellidos'];
$dni= $_REQUEST['dni'];
$password= $_REQUEST['password'];
$urlFoto= $_REQUEST['urlFoto'];
$telefono= $_REQUEST['telefono'];
$email= $_REQUEST['emailuser'];
$direccion= $_REQUEST['direccion'];
$fechaNac= $_REQUEST['fechaNac'];
$observaciones= $_REQUEST['observaciones'];
$numCuenta= $_REQUEST['numCuenta'];
$externo= $_REQUEST['externo'];
$horasExtras= $_REQUEST['horasExtras'];
$profesion= $_REQUEST['profesion'];
$grupo= $_REQUEST['grupo'];
$opcion = $_REQUEST['opcion'];
$usuario= new usuario($nombre,$apellidos,$dni,$password,$urlFoto,$telefono,$email,$direccion,$fechaNac,$observaciones,$numCuenta,$externo,$horasExtras,$profesion,$grupo);
if($opcion=="alta") {
  $usuario->insertar();
  header('location:../vistas/index.php');
}
if($opcion=="modificar"){
  echo"entre";
$usuario -> modificarUsuario();
  header('location:../vistas/index.php');
}
?>;
