<?php
session_start();
include "../modelos/modeloEjemplo.php";
$dni=$_SESSION['dni'];
$apellidos=$_SESSION['apellidos'];
$nombre=$_SESSION['nombre'];
$password=$_SESSION['password'];
$urlFoto=$_SESSION['urlFoto'];
$telefono=$_SESSION['telefono'];
$direccion=$_SESSION['direccion'];
$email=$_SESSION['email'];
$fechaNac=$_SESSION['fechaNac'];
$observaciones=$_SESSION['observaciones'];
$numCuenta=$_SESSION['numCuenta'];
$externo=$_SESSION['externo'];
$horasExtras=$_SESSION['horasExtras'];
$grupo=$_SESSION['grupo'];
$profesion=$_SESSION['profesion'];
$opcion = $_REQUEST['opcion'];
$usuario= new usuario($nombre,$apellidos,$dni,$password,$urlFoto,$telefono,$direccion,$email,$fechaNac,$observaciones,$numCuenta,$externo,$horasExtras,$profesion,$grupo);

if($opcion=="borrar"){
  $usuario->borrarUsuario();
  header('location:../vistas/index.php');
}

if($opcion=="editar"){
  header('location:../vistas/viewModifUser.php');
}

?>;

