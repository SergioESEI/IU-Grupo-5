<html>
	<head>	
		<title> Login</title>
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link href="bootstrap/login.css" rel="stylesheet">
	</head>	

    <body>	  
	<!-- Formulario que recoge los datos de login -->
	<div class="container">
        <div class="card card-container">
			<form class="form-signin" accept-charset="UTF-8" method="POST" action="login.php">
				<fieldset>
					<h1 class="form-signin-heading text-muted">Login</h1>
					
					<!-- Campo que recoge el DNI del usuario -->
					<div class="form-group">
					<h2><small>DNI:</h2></small>
					<input type="text" name="dni" class="form-control" pattern="([0-9]{8}[A-Z]{1})" title="Formato de DNI inválido" required autofocus>
					</div>
					
					<!-- Campo que recoge el password del usuario -->
					<div class="form-group">
					<h2><small>Password:</h2></small>
					<input type="password" name="password" class="form-control" required><br>
					</div>
					
					<!-- Sumbit que envía DNI y password -->
					<button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">ENTRAR</button>
				</fieldset>
			</form>
		</div>
    </div>
	</body>	
</html>	

<?php


//Carga en una variable de sesión los permisos del usuario.
function cargarPermisos($user){
	
	$db = new mysqli('localhost','root','iu','MOOVETT');
	
	$sql = "SELECT Nombre_Controlador,Accion FROM Permisos P, Usuario U WHERE U.Dni='".$user."' AND P.Nombre_Grupo=U.Nombre_Grupo;";
	$result=$db->query($sql);
	if ($result->num_rows > 0){
		return $result->fetch_array();
	}else{
		return null;
	}
}

//Busca al usuario en la BD y vuelve al index si existe.
if(isset($_POST['dni'])){
	
	$db = new mysqli('localhost','root','iu','MOOVETT');
	
	$dni=$_POST['dni'];
	$password=$_POST['password'];
	$password=md5($password); // Encriptamos el password
	$sql="SELECT Nombre_Grupo FROM Usuario WHERE Dni='$dni' and Password='$password'";
	$result=$db->query($sql);	
	
	//Se crean variables de sesión para el usuario (DNI), nombre, grupo al que pertenece y permisos.
	if($result->num_rows == 1){
		session_start();
		$_SESSION['user'] = $dni;
		$array = $result->fetch_array();
		$_SESSION['grupo'] = $array['Nombre_Grupo'];
		$_SESSION['permisos'] = cargarPermisos($dni);

		header("location: index.php");
	}else{
		echo "<div class='col-sm-4 text-left'></div><div class='col-sm-4 text-left'><div class='alert alert-danger'>¡ERROR! Usuario no encontrado.</div></div>";
	}
}
?>
