<?php
$strings = array(
	
	//Cabecera
	'logueado' => 'Logueado como',
	'principal' => 'Principal',
	'desconectarse' => 'Desconectarse',
	'español' => 'Castelán',
	'gallego' => 'Galego',
	
	//Titulos
	'principal' => 'Principal',
	'titulo añadir' => 'Engadir funcionalidade',
	'titulo borrar' => 'Eliminar funcionalidade',
	'titulo editar' => 'Modificar funcionalidade',
	'titulo listar' => 'Ver funcionalidades',
	
	//Menu
	'menu' => 'Menu',
	'gestionarControladores' => 'Xestionar funcionalidades',
	'altaControlador' => 'Engadir funcionalidade',
	'bajaControlador' => 'Eliminar funcionalidade',
	'modificarControlador' => 'Modificar funcionalidade',
	'consultarControlador' => 'Ver funcionalidades',
	
	//Ventanas
	'confirmar borrado' => '¿Confirmar borrado?',
	'confirmar modificacion' => '¿Confrimar modificacion?',
	
	//Opciones controlador controladores
	'nuevo controlador' => 'NOVA FUNCIONALIDADE',
	'borrar controlador' => 'ELIMINAR FUNCIONALIDADE',
	'borrar accion' => 'ELIMINAR ACCIÓN',
	'editar controlador' => 'MODIFICAR FUNCIONALIDADE',
	'ver controlador' => 'VER FUNCIONALIDADES',
	
	//Mensajes modelo controlador
	'añadido correctamente' => 'Controlador engadido correctamente',
	'ya existe' => 'O Controlador xa existe',
	
	//Añadir controlador
	'controlador' => 'Controlador',
	'controladores registrados' => 'Consultar controladores rexistrados',
	'accion' => 'Acción',
	'crear' => 'Engadir',
	'modificar' => 'Modificar',
	'resetear' => 'Resetear',
	
	//Borrar controlador
	'borrar' => 'Eliminar',
	'ir a acciones' => 'Mostrar accións',
	'controlador seleccionado' => 'Controlador seleccionado',
	
	//Modificar controladores
	'nuevos datos' => 'Novos datos',
	
	//Modelo controlador
	'controlador añadido' => 'Controlador engadido correctamente',
	'controlador ya existe' => 'O controlador xa existe',
	'error borrar controlador' => 'Erro ó eliminar controlador',
	'controlador borrado' => 'Controlador eliminado con éxito',
	'controlador modificado' => 'Controlador modificado con éxito',
	'error modificar controlador' => 'Erro ó modificar controlador',
	'controlador ya existe' => 'O controlador a inserir xa existe',
	
	//Cabecera
	'principal' => 'Principal',
	'desconectarse' => 'Desconectarse',
	'español' => 'Castelán',
	'gallego' => 'Galego',
	
	//Menu
	'menu' => 'Menú',
	'gestionarPermisos' => 'Xestionar Permisos',
	'modificarPermisos' => 'Modificar Permisos',
	'consultarPermisos' => 'Consultar Permisos',


	'mostrarPermisos' => 'Amosar Permisos',
	'cambiarPermisos' => 'Cambiar Permisos',
	'escogerGrupo' => 'Escoller grupo e controlador',
	'escogerPermisos' => 'Escoller Permisos',
	'permisos' => 'Permisos',
)
?>
