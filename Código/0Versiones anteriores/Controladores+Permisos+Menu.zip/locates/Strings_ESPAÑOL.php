<?php
$strings = array(

	//Cabecera 
	'logueado' => 'Logueado como',
	'principal' => 'Principal',
	'desconectarse' => 'Desconectarse',
	'español' => 'Español',
	'gallego' => 'Gallego',
	
	//Titulos
	'principal' => 'Principal',
	'titulo añadir' => 'Añadir funcionalidad',
	'titulo borrar' => 'Borrar funcionalidad',
	'titulo editar' => 'Editar funcionalidad',
	'titulo listar' => 'Ver funcionalidades',
	
	//Menu
	'menu' => 'Menú',
	'gestionarControladores' => 'Gestionar funcionalidades',
	'altaControlador' => 'Añadir funcionalidad',
	'bajaControlador' => 'Borrar funcionalidad',
	'modificarControlador' => 'Modificar funcionalidad',
	'consultarControlador' => 'Ver funcionalidades',
	
	//Ventanas
	'confirmar borrado' => '¿Confirmar borrado?',
	'confirmar modificacion' => '¿Confrimar modificación?',
	
	//Opciones controlador controladores
	'nuevo controlador' => 'NUEVA FUNCIONALIDAD',
	'borrar controlador' => 'BORRAR FUNCIONALIDAD',
	'borrar accion' => 'BORRAR ACCIÓN',
	'editar controlador' => 'MODIFICAR FUNCIONALIDAD',
	'ver controlador' => 'VER FUNCIONALIDADES',
	
	//Mensajes modelo controlador
	'añadido correctamente' => 'Controlador añadido correctamente',
	'ya existe' => 'El Controlador ya existe',
	
	//Añadir controlador
	'controlador' => 'Controlador',
	'controladores registrados' => 'Consultar controladores registrados',
	'accion' => 'Acción',
	'crear' => 'Añadir',
	'modificar' => 'Modificar',
	'resetear' => 'Resetear',
	
	//Borrar controlador
	'borrar' => 'Borrar',
	'ir a acciones' => 'Mostrar acciones',
	'controlador seleccionado' => 'Controlador seleccionado',
	
	//Modificar controladores
	'nuevos datos' => 'Nuevos datos',
	
	//Modelo controlador
	'controlador añadido' => 'Controlador añadido correctamente',
	'controlador ya existe' => 'El controlador ya existe',
	'error borrar controlador' => 'Error al borrar controlador',
	'controlador borrado' => 'Controlador borrado con éxito',
	'controlador modificado' => 'Controlador modificado con éxito',
	'error modificar controlador' => 'Error al modificar controlador',
	'controlador ya existe' => 'El controlador a insertar ya existe',
	
	
	//Cabecera 
	'principal' => 'Principal',
	'desconectarse' => 'Desconectarse',
	'español' => 'Español',
	'gallego' => 'Gallego',
	
	//Menu
	'menu' => 'Menú',
	'gestionarPermisos' => 'Gestionar Permisos',
	'consultarPermisos' => 'Consultar Permisos',
	'modificarPermisos' => 'Modificar Permisos',


	'mostrarPermisos' => 'Mostrar Permisos',
	'cambiarPermisos' => 'Cambiar Permisos',
	'escogerGrupo' => 'Escoger grupo y controlador',
	'escogerPermisos' => 'Escoger Permisos',
	'permisos' => 'Permisos',

)
?>
