<html> 
	<div class="col-sm-2 sidenav">
	<?php 
	
	//Muestra distintas opciones en el menú lateral en función del grupo de usuarios al que pertenece.
	if(strcmp($_SESSION['grupo'],"Admin") == 0 ){ ?>
	<h1><small><?php echo $strings['menu']; ?></small></h1>
	<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $strings['gestionarControladores']; ?><span class="caret"></span></a>
          <ul class="dropdown-menu">
			<li>
			  <a href="../controllers/CONTROLADOR_Controller.php?id=altaControlador">
			  <?php echo $strings['altaControlador']; ?></a>
			</li>
			<li>
			  <a href="../controllers/CONTROLADOR_Controller.php?id=bajaControlador">
			  <?php echo $strings['bajaControlador']; ?></a>
			</li>
			<li>
			  <a href="../controllers/CONTROLADOR_Controller.php?id=modificarControlador">
			  <?php echo $strings['modificarControlador']; ?></a>
			</li>
			<li>
			  <a href="../controllers/CONTROLADOR_Controller.php?id=consultarControlador">
			  <?php echo $strings['consultarControlador']; ?></a>
			</li>
          </ul>
        </li>
		<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Gestionar permisos<span class="caret"></span></a>
          <ul class="dropdown-menu">
			<li>
			  <a href="../controllers/PERMISO_Controller.php?id=altaPermiso">
			  Añadir permiso</a>
			</li>
			<li>
			  <a href="../controllers/PERMISO_Controller.php?id=bajaPermiso">
			  Borrar permiso</a>
			</li>
			<li>
			  <a href="../controllers/PERMISO_Controller.php?id=modificarPermiso">
			  Modificar permiso</a>
			</li>
			<li>
			  <a href="../controllers/PERMISO_Controller.php?id=consultarPermiso">
			  Ver permisos</a>
			</li>
          </ul>
        </li>			
	<?php } ?>	
	</div>
</html>